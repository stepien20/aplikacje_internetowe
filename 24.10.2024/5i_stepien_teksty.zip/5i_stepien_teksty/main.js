const but=document.querySelector(`#action`)
but.addEventListener(`click`,()=>
{
const articles=document.querySelectorAll(`section p`)
const znaki=['?','!',"."]
articles.forEach(article => {
    paragraph=article.innerHTML
    const wyrazy=paragraph.split(' ');
    sentenceCount=0; 
    letteroCount=0;
    wyrazy.forEach(wyraz => {
        if (wyraz.includes(znaki[0])||wyraz.includes(znaki[1])||wyraz.includes(znaki[2])){
            sentenceCount++
        }
        if(wyraz.includes('o')){letteroCount++
        }
    });
    const section=article.parentElement
    elem=document.createElement(`p`)
    elem.id="added"
    elem.innerHTML=`ilosc zdan: ${sentenceCount} <br> ilość zdan z 'o': ${letteroCount}`;
    let test=section.querySelector(`#added`)
    if(test){
        section.removeChild(test)
    }
    section.appendChild(elem)
});
});